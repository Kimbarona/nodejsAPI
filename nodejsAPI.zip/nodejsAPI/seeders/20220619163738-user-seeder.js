'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
   
     await queryInterface.bulkInsert('users', [
      {
        FirstName: "TJ",
        LastName: "Monterde",
        Address: "Apalit, Pampanga",
        PostCode: "2011",
        CPNumber : "09285664411",
        Email: "tj@gamil.com",
        UserName: "tj",
        Password: "tj"
      },
      {
        FirstName: "Hernanie",
        LastName: "Pabustan",
        Address: "Minalin",
        PostCode: "2011",
        CPNumber : "09285664412",
        Email: "hernanie@gamil.com",
        UserName: "hernanie",
        Password: "hernanie"
      },
      {
        FirstName: "Patrick",
        LastName: "Laxamana",
        Address: "Apalit, Pampanga",
        PostCode: "2011",
        CPNumber : "09285664413",
        Email: "pat@gamil.com",
        UserName: "pat",
        Password: "pat"
      },

    ], {});
    
  },

  async down (queryInterface, Sequelize) {

     await queryInterface.bulkDelete('users', null, {});
    
  }
};
