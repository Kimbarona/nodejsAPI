const express = require('express');
const userController = require('../controller/user.controller');
const checkAuthMiddleware = require('../middleware/check-auth');

const router = express.Router()

router.post('/', checkAuthMiddleware.checkAuth, userController.save);
router.get('/:id', userController.show);
router.get('/', userController.index);
router.patch('/:id',checkAuthMiddleware.checkAuth, userController.update);
router.delete('/:id',checkAuthMiddleware.checkAuth, userController.destroy);

router.post('/login', userController.login);


module.exports  = router;