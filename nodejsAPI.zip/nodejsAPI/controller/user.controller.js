const models = require('../models')
const bodyParser = require('body-parser');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');

function save (req, res){

    models.User.findOne({where: {email:req.body.Email}}).then(result =>{
        if(result){
            res.status(409).json({
                message: "Email Already Exist!"
            })
        }else{
            bcrypt.genSalt(10, function(err, salt){
                bcrypt.hash(req.body.Password, salt, function(err, hash){
                    const user = {
                        FirstName: req.body.FirstName,
                        LastName: req.body.LastName,
                        Address: req.body.Address,
                        PostCode: req.body.PostCode,
                        CPNumber: req.body.CPNumber,
                        Email: req.body.Email,
                        UserName: req.body.UserName,
                        Password: hash
                    }
                
                    models.User.create(user).then(
                        result => {
                            res.status(201).json({
                                message: "User created successfully.",
                                user: result
                            })
                        }).catch(error =>{
                            res.status(500).json({
                                message: "opps! something wen't wrong!",
                                error: error
                            })
                        }
                    )
                });
            });
        }
    }).catch(error => {
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

function show (req, res){
    const id = req.params.id;

    models.User.findByPk(id).then(result =>{
        
        if(result){
            res.status(200).json(result);
        }else{
            res.status(200).json({
                message: "No Data Found!"
            });
        }
    }).catch(error =>{
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

function index (req, res){
    models.User.findAll().then(result =>{
        if(result){
            res.status(200).json(result);
        }else{
            res.status(200).json({
                message: "No Data Found!"
            });
        }
    }).catch(error =>{
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

function update (req, res){
    const id = req.params.id;
    const updateUser = {
        FirstName: req.body.FirstName,
        LastName: req.body.LastName,
        Address: req.body.Address,
        PostCode: req.body.PostCode,
        CPNumber: req.body.CPNumber,
        Email: req.body.Email,
        UserName: req.body.UserName,
        // Password: req.body.Password
    }

    models.User.update(updateUser, {where: {id:id}}).then(result =>{
        res.status(200).json({
            message: "User Updated Successfully.",
            user: result
        });
    }).catch(error =>{
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

function destroy (req, res){
    const id = req.params.id;

    models.User.destroy({where: {id:id}}).then(result =>{
        if(result){
            res.status(200).json({
                message: "User Successfully Deleted."
            });
        }else{
            res.status(200).json({
                message: "No Data Found!"
            });
        }
        
    }).catch(error =>{
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

function login (req, res){
    models.User.findOne({where:{username: req.body.UserName}}).then(user => {
        if(user === null){
            res.status(401).json({
                message: "Invalid Credentials!",
            })
        }else{
            bcrypt.compare(req.body.Password, user.Password, function(err, result){
                if(result){
                    const token = jwt.sign({
                        username: user.UserName,
                        id: user.id
                    }, process.env.JWT_KEY, function(err, token){
                        res.status(200).json({
                            message: "Login Successfully",
                            token: token
                        })
                    });
                }else{
                    res.status(401).json({
                        message: "Invalid Credentials!",
                    })
                }
            })
        }
    }).catch(erron => {
        res.status(500).json({
            message: "opps! something wen't wrong!",
            error: error
        })
    })
}

module.exports = {
    save: save,
    show: show,
    index: index,
    update: update,
    destroy: destroy,
    login: login
}